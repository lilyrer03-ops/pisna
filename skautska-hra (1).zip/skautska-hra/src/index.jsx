// React entry point with Router
