// Scoreboard component
