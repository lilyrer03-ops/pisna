// Admin page for QR + questions
