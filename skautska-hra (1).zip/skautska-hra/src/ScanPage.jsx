// Scan page with QR logic
