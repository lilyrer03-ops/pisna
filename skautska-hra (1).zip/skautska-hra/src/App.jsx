// Main app component
